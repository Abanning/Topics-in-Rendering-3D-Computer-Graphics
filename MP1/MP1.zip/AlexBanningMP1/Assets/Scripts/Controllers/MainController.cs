using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

[ExecuteAlways]
public class MainController : MonoBehaviour
{
    // The World Model
    private TheWorld theWorld;

    // Sliders
    private Slider RSlider;
    private SliderWithEcho RSliderController;
    private Slider GSlider;
    private SliderWithEcho GSliderController;
    private Slider BSlider;
    private SliderWithEcho BSliderController;
    private Color currentColor = new Color(1f, 1f, 1f, 1f);

    // Reset Button
    private Button resetButton;

    // Currently Selected Object
    private GameObject currentlySelectedObject = null;
    private TextMeshProUGUI currentlySelectedEcho;

    private LayerMask selectableLayerMask;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        theWorld = GameObject.Find("TheWorld").GetComponent<TheWorld>();

        selectableLayerMask = LayerMask.GetMask("Selectable");

        RSlider = GameObject.Find("RSlider").GetComponent<Slider>();
        RSliderController = GameObject.Find("SliderWithEchoR").GetComponent<SliderWithEcho>();
        RSliderController.SetSliderListener(RSliderListener);

        GSlider = GameObject.Find("GSlider").GetComponent<Slider>();
        GSliderController = GameObject.Find("SliderWithEchoG").GetComponent<SliderWithEcho>();
        GSliderController.SetSliderListener(GSliderListener);

        BSlider = GameObject.Find("BSlider").GetComponent<Slider>();
        BSliderController = GameObject.Find("SliderWithEchoB").GetComponent<SliderWithEcho>();
        BSliderController.SetSliderListener(BSliderListener);

        RSlider.enabled = false;
        GSlider.enabled = false;
        BSlider.enabled = false;

        resetButton = GameObject.Find("ResetButton").GetComponent<Button>();
        resetButton.onClick.AddListener(() => theWorld.ResetWorld());

        currentlySelectedEcho = GameObject.Find("CurrentlySelectedLabel").GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        CheckForMouseClick();
    }

    private void RSliderListener(float v)
    {
        currentColor.r = v;
        SliderHandler();
    }

    private void GSliderListener(float v)
    {
        currentColor.g = v;
        SliderHandler();
    }

    private void BSliderListener(float v)
    {
        currentColor.b = v;
        SliderHandler();
    }

    private void SliderHandler()
    {
        theWorld.SetCurrentColor(currentColor);
    }

    private void CheckForMouseClick()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
            {
                return; // click was on UI
            }
            if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out RaycastHit hit, Mathf.Infinity, selectableLayerMask))
            {
                SelectObject(hit.transform.gameObject);
            }
            else
            {
                RSliderController.isActive = false;
                GSliderController.isActive = false;
                BSliderController.isActive = false;
                RSliderController.SetSliderValue(0f);
                GSliderController.SetSliderValue(0f);
                BSliderController.SetSliderValue(0f);
                currentlySelectedObject = null;
                theWorld.SetCurrentlySelectedObject(null);
                currentlySelectedEcho.text = "Currently Selected: None";
                RSlider.enabled = false;
                GSlider.enabled = false;
                BSlider.enabled = false;
                return;
            }
        }
    }

    private void SelectObject(GameObject obj)
    {
        if (obj == currentlySelectedObject) return;

        // Set hit object as currently selected
        currentlySelectedObject = obj;
        theWorld.SetCurrentlySelectedObject(currentlySelectedObject);
        currentlySelectedEcho.text = "Currently Selected: " + currentlySelectedObject.name;

        // Get current color of selected object
        Renderer rend = currentlySelectedObject.GetComponent<Renderer>();
        if (rend != null)
        {
            currentColor = rend.material.color;
            RSlider.enabled = true;
            GSlider.enabled = true;
            BSlider.enabled = true;
            RSliderController.isActive = false;
            GSliderController.isActive = false;
            BSliderController.isActive = false;
            RSliderController.SetSliderValue(currentColor.r);
            GSliderController.SetSliderValue(currentColor.g);
            BSliderController.SetSliderValue(currentColor.b);
            theWorld.SetCurrentColor(currentColor);
            RSliderController.isActive = true;
            GSliderController.isActive = true;
            BSliderController.isActive = true;
            return;
        }
    } 
}
