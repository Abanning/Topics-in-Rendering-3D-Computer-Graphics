using UnityEngine;
using System;

[ExecuteAlways]
[RequireComponent(typeof(Renderer))]
public class PerObjectColor : MonoBehaviour
{
    [SerializeField]
    private Color color = Color.white;

    public event Action<PerObjectColor, Color> OnColorChanged;

    private Renderer _renderer;
    private Material _runtimeMaterial;

    void Awake()
    {
        _renderer = GetComponent<Renderer>();

        if (Application.isPlaying)
            EnsureRuntimeMaterial();

        Apply();
    }

#if UNITY_EDITOR
    void OnValidate()
    {
        if (Application.isPlaying)
            return;

        if (_renderer == null)
            _renderer = GetComponent<Renderer>();

        if (_renderer.sharedMaterial != null)
            _renderer.sharedMaterial.SetColor("_Color", color);

        // 🔔 Notify editor-driven change
        OnColorChanged?.Invoke(this, color);
    }
#endif

    public Color Color
    {
        get => color;
        set
        {
            if (color == value) return;
            color = value;
            Apply();
            OnColorChanged?.Invoke(this, color);
        }
    }

    void Apply()
    {
        if (!Application.isPlaying || _renderer == null)
            return;

        EnsureRuntimeMaterial();
        _runtimeMaterial.SetColor("_Color", color);
    }

    void EnsureRuntimeMaterial()
    {
        if (_runtimeMaterial == null)
            _runtimeMaterial = _renderer.material;
    }

    void OnDestroy()
    {
        if (Application.isPlaying && _runtimeMaterial != null)
            Destroy(_runtimeMaterial);
    }
}
