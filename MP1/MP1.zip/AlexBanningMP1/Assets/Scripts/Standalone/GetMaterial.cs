using UnityEngine;

[ExecuteAlways]
public class GetMaterial : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Material mat = gameObject.GetComponent<Renderer>().material;
    }
}
