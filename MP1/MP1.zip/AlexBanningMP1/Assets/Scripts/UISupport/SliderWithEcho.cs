﻿// @author: Kelvin Sung
// @last-modified: October 17th, 2025 (by Alex Banning)
// @filename-and-path: AlexBanningMP3/Assets/Scripts/UI\ Support/SliderWithEcho.cs
// @description: Prefab made by Kelvin Sung, adapted to fit my needs

using UnityEngine;
using UnityEngine.UI;
using TMPro;  // Text Mesh Pro

[ExecuteAlways]
public class SliderWithEcho : MonoBehaviour 
{
    public Slider TheSlider = null;
    public TextMeshProUGUI TheEcho = null;
    public TextMeshProUGUI TheLabel = null;

    public delegate void SliderCallbackDelegate(float v);      // defined a new data type
    private SliderCallbackDelegate mCallBack = null;           // private instance of the data type
    public bool isActive = true;


	// Use this for initialization
	void Start () {
        if (!TheSlider)
        {
            Debug.Log("Error: Could not find Sider Component!");
            Destroy(this);
        }

        TheSlider.onValueChanged.AddListener(SliderValueChange);
    }

    public void SetSliderListener(SliderCallbackDelegate listener) => mCallBack = listener;

    // GUI element changes the object
    void SliderValueChange(float v)
    {
        TheEcho.text = v.ToString("0.0000");
        if (mCallBack != null && isActive)
            mCallBack(v);
    }

    public float GetSliderValue() { return TheSlider.value; }
    public void SetSliderLabel(string l) { TheLabel.text = l; }
    public void SetSliderValue(float v) { TheSlider.value = v; SliderValueChange(v); }
    public void InitSliderRange(float min, float max, float v)
    {
        Debug.Log("Initializing slider values @: min=" + min + ", max=" + max + ", value=" + v);
        TheSlider.minValue = min;
        TheSlider.maxValue = max;
        SetSliderValue(v);
    }
}