using UnityEngine;
using UnityEngine.SceneManagement;

[ExecuteAlways]
public class TheWorld : MonoBehaviour
{
    public GameObject currentlySelected;
    public Color currentColor;

    public void SetCurrentlySelectedObject(GameObject obj)
    {
        currentlySelected = obj;

        if (obj != null)
        {
            var poc = obj.GetComponent<PerObjectColor>();
            if (poc != null)
                currentColor = poc.Color;
        }
    }

    public void SetCurrentColor(Color color)
    {
        currentColor = color;

        if (currentlySelected != null)
        {
            /*
            var poc = currentlySelected.GetComponent<PerObjectColor>();
            if (poc != null)
                poc.Color = currentColor;
                */
                
            Renderer rend = currentlySelected.GetComponent<Renderer>();
            if (rend != null)
            {
                rend.material.color = currentColor;
            }
        }
    }

    public void ResetWorld()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
