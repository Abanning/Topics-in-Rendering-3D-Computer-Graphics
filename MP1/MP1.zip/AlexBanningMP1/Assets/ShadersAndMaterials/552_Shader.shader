Shader "552_Shaders/552_Shader"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
        _Color ("Color", Color) = (1, 1, 1, 1)
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            HLSLPROGRAM
            #pragma vertex VertexProgram
            #pragma fragment FragmentProgram

            #include "UnityCG.cginc"

            struct DataFromVertex
            {
                float4 vertex : POSITION;
                float2 uv : TEXCOORD0;
            };

            struct DataForFragmentShader
            {
                float2 uv : TEXCOORD0;
                float4 vertex : SV_POSITION;
            };

            sampler2D _MainTex;
            float4 _MainTex_ST;
            float4 _Color;

            DataForFragmentShader VertexProgram (DataFromVertex data)
            {
                DataForFragmentShader output;
                float4 p;
                p = data.vertex;

                p = mul(unity_ObjectToWorld, p);
                p = mul(UNITY_MATRIX_V, p);
                p = mul(UNITY_MATRIX_P, p);
                output.vertex = p;

                output.uv = TRANSFORM_TEX(data.uv, _MainTex);
                
                return output;
            }

            fixed4 FragmentProgram (DataForFragmentShader data) : SV_Target
            {
                // sample the texture
                fixed4 OutputFromFragmentShader = tex2D(_MainTex, data.uv) * _Color;
                return OutputFromFragmentShader;
            }
            ENDHLSL
        }
    }
}
